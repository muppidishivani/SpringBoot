package com.sathya.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
