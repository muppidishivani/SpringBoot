package com.sathya.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.sathya.employee.dto.LoginDto;
import com.sathya.employee.dto.UserDto;
import com.sathya.employee.entity.Users;
import com.sathya.employee.repo.UserRepo;

@Service
public class UserService {
	
	@Autowired
	private UserRepo userRepo;
	
	public Users saveUser(UserDto userDto) {
		
		Users user=new Users();
		user.setEmail(userDto.getEmail());
		
		user.setPassword(userDto.getPassword());
		user.setMobileNumber(userDto.getMobileNumber());
		user.setLocation(userDto.getLocation());
		user.setUserName(userDto.getUserName());
		return userRepo.save(user);
		
	}
	
    public List<Users> getAllUsers() {
    	return userRepo.findAll();
	} 
    
    public void deleteUser(Long id) {
    	userRepo.deleteById(id);
    }
    
    public Users getById(Long id) {
    	return userRepo.findById(id).get();
    }
    
    public void update(Users user) {
    	userRepo.save(user);
    }
    public Users saveStudent(Users student) {
    	userRepo.save(student);
    	return student;
    }
public String loginValidate(LoginDto dto) {
    	
    	boolean flag=false;
    	Optional<Users> user=userRepo.findByUserName( dto.getUsername());
    	if(user.isEmpty()) flag= false;
    	
    	else {
    		if(user.get().getPassword().equals(dto.getPassword())) flag= true;
    		else flag= false;
    	}
    	
    	if(flag) return "Login succesfully";
    	else return "Login filaed";
    	
    }

}
