package com.sathya.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcJspApplication.class, args);
	}

}
