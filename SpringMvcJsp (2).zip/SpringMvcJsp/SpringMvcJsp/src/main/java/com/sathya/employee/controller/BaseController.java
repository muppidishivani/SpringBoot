package com.sathya.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.sathya.employee.dto.LoginDto;
import com.sathya.employee.dto.UserDto;
import com.sathya.employee.entity.Users;
import com.sathya.employee.service.UserService;

@Controller
public class BaseController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping()
	public String basePage(Model model) {
		model.addAttribute("users", userService.getAllUsers());

		return "index";
	}
	
	@PostMapping("/register")
	public String createUser(@ModelAttribute UserDto userDto)
	{
		userService.saveUser(userDto);
		
		return "redirect:/?page=login";
	}
	
	
	@GetMapping("/users")
	public String getAllUsers(ModelMap model) {
		model.put("listOfUsers",userService.getAllUsers());
		return "index";
	} 
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable Long id) {
		userService.deleteUser(id);
		return "redirect:/?page=user";
	} 
	
	@PostMapping("/user/update")
    public String updateUser(Users user, Model model) {
        userService.update(user);
        return "redirect:/?page=user"; // Redirect to the user list page
    }
	
	@GetMapping("/user/{id}")
	public String showUpdateForm(@PathVariable Long id,ModelMap m) {
		m.put("user",userService.getById(id));
		return "updatePage";
	} 
	
	@PostMapping("/login")
	public String loginValidate(@ModelAttribute LoginDto dto,Model map) {
		userService.loginValidate(dto);
		map.addAttribute("message", userService.loginValidate(dto));
		return "sucess";
	}
	
}
